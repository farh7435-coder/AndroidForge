package com.darkfrensz.panel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*

private val BG = Color(0xFF061016)
private val CARD = Color(0xFF111114)
private val CYAN = Color(0xFF00E5F2)
private val RED = Color(0xFFE51D3D)
private val MUTED = Color(0xFF85858D)

private data class DemoCard(val name: String, val tag: String)
private data class LocalAccount(val username: String, val password: String, val role: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DarkFrenszOwnerApp() }
    }
}

@Composable
fun DarkFrenszOwnerApp() {
    // Demo credentials are intentionally local/in-memory; they are not production authentication.
    val accounts = remember {
        mutableStateListOf(
            LocalAccount("JunaaStur", "MEGAZIME", "OWNER"),
            LocalAccount("memberdemo", "member123", "MEMBER"),
            LocalAccount("trialdemo", "trial123", "TRIAL")
        )
    }
    var loggedIn by remember { mutableStateOf(false) }
    var signedUser by remember { mutableStateOf("") }
    var signedRole by remember { mutableStateOf("") }
    var loginUser by remember { mutableStateOf("JunaaStur") }
    var loginPass by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Dashboard") }
    var target by remember { mutableStateOf("") }
    var chosen by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var newUser by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var newRole by remember { mutableStateOf("MEMBER") }

    val cards = listOf(
        DemoCard("BLANK HARD", "#blankhard"), DemoCard("BLANK MATOT", "#blankmatot"),
        DemoCard("FORCLOSE", "#iosXv"), DemoCard("FORCLOSE V2", "#forclose"),
        DemoCard("FC CLICK", "#Cxinv"), DemoCard("FC NO CLICK", "#fcno"),
        DemoCard("FORCLOSE 1MSG", "#demo_one"), DemoCard("FC INVIS IOS", "#ios_invis"),
        DemoCard("FORCLOSE INVIS", "#delayhard"), DemoCard("FORCE CALL", "#forcecall"),
        DemoCard("DELAY INVIS", "#delayinvis"), DemoCard("DELAY JEMBUD", "#delayv1"),
        DemoCard("DELAY HARD", "#delayhard"), DemoCard("DELAY X CRASH", "#dxc")
    )

    MaterialTheme(colorScheme = darkColorScheme(primary = CYAN, background = BG, surface = CARD, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(BG)) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                if (!loggedIn) {
                    Spacer(Modifier.height(65.dp))
                    Column(Modifier.padding(22.dp).fillMaxWidth().background(CARD, RoundedCornerShape(22.dp)).padding(22.dp)) {
                        Text("DARK FRENSZ", color = CYAN, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        Text("ROLE-BASED MEMBER PANEL", color = CYAN.copy(alpha = .8f), fontSize = 12.sp)
                        Spacer(Modifier.height(24.dp))
                        Text("LOGIN PANEL", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(loginUser, { loginUser = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(loginPass, { loginPass = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = {
                            val account = accounts.firstOrNull { it.username == loginUser.trim() && it.password == loginPass }
                            if (account != null) {
                                signedUser = account.username
                                signedRole = account.role
                                loggedIn = true
                                page = "Dashboard"
                                notice = ""
                            } else notice = "Username atau password salah."
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = CYAN)) {
                            Text("MASUK", color = BG, fontWeight = FontWeight.Bold)
                        }
                        if (notice.isNotBlank()) Text(notice, color = RED, modifier = Modifier.padding(top = 8.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Owner demo: JunaaStur / MEGAZIME", color = MUTED, fontSize = 12.sp)
                        Text("Member: memberdemo / member123", color = MUTED, fontSize = 12.sp)
                        Text("Trial: trialdemo / trial123", color = MUTED, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Mode lokal • tidak terhubung ke WhatsApp", color = MUTED, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                } else {
                    Row(Modifier.fillMaxWidth().background(Color(0xCC26343A)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("☰", color = CYAN, fontSize = 25.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Halo $signedUser 👋", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("ROLE: $signedRole  •  DARK FRENSZ", color = CYAN, fontSize = 11.sp)
                        }
                        Icon(Icons.Default.AccountCircle, null, tint = Color.White)
                    }

                    Row(Modifier.padding(16.dp).fillMaxWidth().background(CARD, RoundedCornerShape(20.dp)).padding(14.dp), horizontalArrangement = Arrangement.SpaceAround) {
                        Stat(accounts.size.toString(), "Accounts")
                        Stat(signedRole, "Your Role")
                        Stat("ONLINE", "Demo Status")
                    }

                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Dashboard", "Accounts", "Profile").forEach { tab ->
                            FilterChip(selected = page == tab, onClick = { page = tab }, label = { Text(tab) })
                        }
                    }

                    when (page) {
                        "Dashboard" -> {
                            Text("‹  Pilih Mode Simulasi", color = Color.White, modifier = Modifier.padding(start = 22.dp, top = 12.dp, bottom = 12.dp))
                            Column(Modifier.padding(horizontal = 18.dp).fillMaxWidth().background(Color(0xAA101A20), RoundedCornerShape(18.dp)).padding(14.dp)) {
                                Text("▣  Nomor Target Demo (opsional)", color = Color(0xFFD08C9A), fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(target, { target = it }, placeholder = { Text("Contoh: target-demo") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                Text("Input hanya untuk tampilan; tidak dikirim ke layanan lain.", color = MUTED, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("⚙  Kartu Simulasi", color = Color(0xFFD08C9A), modifier = Modifier.padding(start = 22.dp, bottom = 10.dp))
                            LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().height(1000.dp).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), userScrollEnabled = false) {
                                items(cards) { item ->
                                    Column(Modifier.height(166.dp).fillMaxWidth().background(CARD, RoundedCornerShape(20.dp)).border(1.dp, Color(0xFF29292E), RoundedCornerShape(20.dp)).clickable { chosen = item.name; notice = "$chosen dipilih untuk simulasi UI saja." }.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                        Box(Modifier.size(48.dp).background(RED, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Security, null, tint = Color.White, modifier = Modifier.size(25.dp))
                                        }
                                        Column {
                                            Text(item.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Spacer(Modifier.height(4.dp)); Text(item.tag, color = MUTED, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                            if (chosen.isNotBlank()) Text(notice, color = CYAN, modifier = Modifier.padding(20.dp))
                        }
                        "Accounts" -> {
                            Column(Modifier.padding(18.dp).fillMaxWidth().background(CARD, RoundedCornerShape(18.dp)).padding(16.dp)) {
                                Text("ACCOUNT MANAGEMENT", color = CYAN, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                Text("Owner dapat membuat username/password untuk Member atau Trial.", color = MUTED, fontSize = 12.sp)
                                Spacer(Modifier.height(12.dp))
                                if (signedRole == "OWNER") {
                                    OutlinedTextField(newUser, { newUser = it }, label = { Text("Username baru") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(newPass, { newPass = it }, label = { Text("Password baru") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    Spacer(Modifier.height(8.dp))
                                    Text("Role akun baru", color = Color.White)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        FilterChip(selected = newRole == "MEMBER", onClick = { newRole = "MEMBER" }, label = { Text("Member") })
                                        FilterChip(selected = newRole == "TRIAL", onClick = { newRole = "TRIAL" }, label = { Text("Trial") })
                                    }
                                    Button(onClick = {
                                        val clean = newUser.trim()
                                        when {
                                            clean.isBlank() || newPass.length < 6 -> notice = "Isi username dan password minimal 6 karakter."
                                            accounts.any { it.username.equals(clean, ignoreCase = true) } -> notice = "Username sudah digunakan."
                                            else -> {
                                                accounts.add(LocalAccount(clean, newPass, newRole))
                                                notice = "Akun $clean berhasil dibuat dengan role $newRole."
                                                newUser = ""; newPass = ""
                                            }
                                        }
                                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = CYAN)) {
                                        Text("BUAT AKUN", color = BG, fontWeight = FontWeight.Bold)
                                    }
                                    if (notice.isNotBlank()) Text(notice, color = CYAN, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                                } else {
                                    Text("Akses ditolak. Hanya OWNER yang dapat membuat akun.", color = RED)
                                }
                                Spacer(Modifier.height(16.dp))
                                Text("DAFTAR AKUN (lokal)", color = Color.White, fontWeight = FontWeight.Bold)
                                accounts.forEach { acc ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp).background(Color(0xFF1A222A), RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(acc.username, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text("ROLE: ${acc.role}", color = if (acc.role == "OWNER") CYAN else MUTED, fontSize = 11.sp)
                                        }
                                        if (signedRole == "OWNER" && acc.role != "OWNER") {
                                            TextButton(onClick = { accounts.remove(acc); notice = "Akun ${acc.username} dihapus." }) { Text("Hapus", color = RED) }
                                        }
                                    }
                                }
                            }
                        }
                        else -> {
                            Column(Modifier.padding(18.dp).fillMaxWidth().background(CARD, RoundedCornerShape(18.dp)).padding(20.dp)) {
                                Text("PROFILE", color = CYAN, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Username: $signedUser", color = Color.White)
                                Text("Role: $signedRole", color = CYAN)
                                Text("Aplikasi demo lokal; daftar akun hilang saat aplikasi ditutup.", color = MUTED, fontSize = 12.sp)
                                Spacer(Modifier.height(16.dp))
                                Button(onClick = { loggedIn = false; loginUser = "JunaaStur"; loginPass = ""; notice = "" }, colors = ButtonDefaults.buttonColors(containerColor = CYAN)) {
                                    Text("LOGOUT", color = BG)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth().background(Color.Black).padding(12.dp), horizontalArrangement = Arrangement.SpaceAround) {
                        IconButton(onClick = { page = "Dashboard" }) { Icon(Icons.Default.Home, null, tint = if (page == "Dashboard") CYAN else MUTED) }
                        IconButton(onClick = { page = "Profile" }) { Icon(Icons.Default.Info, null, tint = MUTED) }
                        IconButton(onClick = { page = "Accounts" }) { Icon(Icons.Default.People, null, tint = if (page == "Accounts") CYAN else MUTED) }
                        IconButton(onClick = { page = "Profile" }) { Icon(Icons.Default.Settings, null, tint = MUTED) }
                        IconButton(onClick = { loggedIn = false; loginPass = ""; notice = "" }) { Icon(Icons.Default.Logout, null, tint = RED) }
                    }
                }
            }
            if (loggedIn && page == "Dashboard") {
                Column(Modifier.align(Alignment.BottomEnd).padding(bottom = 75.dp, end = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(58.dp).background(RED, RoundedCornerShape(50)).border(2.dp, Color(0xFFFF6A8B), RoundedCornerShape(50)).clickable { notice = "Tombol ini hanya demo visual; tidak ada aksi eksternal." }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.BugReport, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                    Text("DEMO", color = RED, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontSize = if (value.length > 6) 12.sp else 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = RED, fontSize = 11.sp)
    }
}
