# DARK FRENSZ — Owner + Role Management

Android demo panel bertema hitam/cyan dengan layout kartu dua kolom, header member, navigasi, serta sistem role lokal.

## Login demo
- OWNER: `JunaaStur` / `MEGAZIME`
- MEMBER: `memberdemo` / `member123`
- TRIAL: `trialdemo` / `trial123`

## Fitur role
- **OWNER**: dapat membuat akun Member atau Trial dengan username/password sendiri dan menghapus akun non-owner.
- **MEMBER**: dapat melihat dashboard dan profil; tidak dapat membuat akun.
- **TRIAL**: akses demo dasar; tidak dapat membuat akun.
- Pembuatan akun hanya tersimpan di memori selama aplikasi terbuka. Aplikasi ditutup = akun baru kembali ke data demo awal.

## Build APK
1. Instal Android Studio stabil.
2. Ekstrak ZIP dan buka folder `DARK_FRENSZ_OWNER`.
3. Tunggu Gradle Sync; pasang Android SDK Platform 35 jika diminta.
4. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Keamanan dan batasan
Ini starter project lokal untuk demo, bukan sistem akun produksi. Password disimpan sementara di memori dan bukan backend aman. Untuk penggunaan publik perlu backend autentikasi, password hashing, database, kontrol akses sisi server, serta kebijakan reset password. Kartu dan tombol bug hanya simulasi visual; aplikasi tidak mengirim payload atau perintah ke WhatsApp/perangkat lain.
